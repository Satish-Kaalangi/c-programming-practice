#include <stdio.h>
int main(){
    int x,y,z;
    x=0;
    y=0;
    z=0;
    
    printf("enter your first number......");
    scanf("%d" , &x);
    
    printf("enter your second number......");
    scanf("%d" , &y);
    
    z=x+y;
    printf("the result is %d" ,z);
}
